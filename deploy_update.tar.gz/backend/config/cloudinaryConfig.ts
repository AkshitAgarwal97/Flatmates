import { v2 as cloudinary } from 'cloudinary';

// Config is now done in server.ts after dotenv loads
// Just export the cloudinary instance
export default cloudinary;
