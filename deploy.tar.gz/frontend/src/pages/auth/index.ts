import Login from './Login';
import Register from './Register';
import CompleteProfile from './CompleteProfile';
import AuthSuccess from './AuthSuccess';

export { Login, Register, CompleteProfile, AuthSuccess };